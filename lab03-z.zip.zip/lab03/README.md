# Login Demo (PHP Sessions)

## How to run (XAMPP)
1. Start **Apache** in XAMPP.
2. Put this folder at:
   `C:\xampp\htdocs\3363winter\log-in-out\`
3. Open in browser:
   http://localhost/3363winter/log-in-out.php

## Demo credentials
- Email: student@example.com
- Password: Password123!

## Concepts
- POST form handling
- Required checks on the server
- Sessions for login state
- Escaping output with htmlspecialchars()
