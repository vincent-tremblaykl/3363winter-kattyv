<?php
// authenticate.php
session_start();

$email    = trim($_POST['email'] ?? '');
$password = $_POST['password'] ?? '';

// Demo user (pretend this came from a database)
$demoEmail = 'student@example.com';

// For demo simplicity, we hash on each request.
// In a real app, you'd store the hash once in a database.
$demoHash = password_hash('Password123!', PASSWORD_DEFAULT);

// Basic required checks
if ($email === '' || $password === '') {
  header('Location: login.php?error=1');
  exit;
}

// Verify email + password
if ($email === $demoEmail && password_verify($password, $demoHash)) {
  session_regenerate_id(true);           // reduce session fixation risk
  $_SESSION['user_email'] = $email;      // store logged-in state
  header('Location: dashboard.php');
  exit;
}

header('Location: login.php?error=1');
exit;
