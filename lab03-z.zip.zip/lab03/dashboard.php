<?php
// dashboard.php
session_start();

// Protect page
if (empty($_SESSION['user_email'])) {
  header('Location: login.php');
  exit;
}
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Dashboard</title>
</head>
<body>
  <h1>Dashboard</h1>
  <p>Welcome, <?= htmlspecialchars($_SESSION['user_email'], ENT_QUOTES, 'UTF-8') ?></p>
  <p><a href="logout.php">Log out</a></p>
</body>
</html>
