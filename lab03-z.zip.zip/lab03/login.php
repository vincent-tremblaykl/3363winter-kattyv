<?php
// login.php
// Simple login form + error display
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Login Demo</title>
</head>
<body>
  <h1>Login</h1>

  <?php if (!empty($_GET['error'])): ?>
    <p style="color:red;">Invalid login</p>
  <?php endif; ?>

  <form action="authenticate.php" method="post">
    <label>Email</label><br>
    <input type="email" name="email" required><br><br>

    <label>Password</label><br>
    <input type="password" name="password" required><br><br>

    <button type="submit">Log in</button>
  </form>

  <p><strong>Demo credentials:</strong><br>
    Email: <code>student@example.com</code><br>
    Password: <code>Password123!</code>
  </p>
</body>
</html>
