<?php
// logout.php
session_start();

$_SESSION = [];      // clear session array
session_destroy();   // destroy session
header('Location: login.php');
exit;
